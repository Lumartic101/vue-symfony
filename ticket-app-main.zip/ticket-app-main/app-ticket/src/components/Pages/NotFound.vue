<template>
  <h1>404 Page</h1>
</template>

<script>
export default {
  name: 'PageNotFound',
};
</script>

<style scoped>
h1 {
  color: orange;
}
</style>
