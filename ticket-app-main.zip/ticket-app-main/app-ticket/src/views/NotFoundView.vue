<template>
  <main>
    <NotFound/>
  </main>
</template>

<script lang="ts" setup>
import NotFound from '@/components/Pages/NotFound.vue';
</script>
