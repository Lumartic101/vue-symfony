<script setup lang="ts">
import ViewTickets from '@/components/Organisms/ViewTickets.vue';
</script>

<template>
  <main>
    <ViewTickets/>
  </main>
</template>
